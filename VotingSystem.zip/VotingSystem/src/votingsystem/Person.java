package votingsystem;

import java.util.Scanner;

public class Person {

    public Person(String name,int age)
    {

    }
    public boolean Vote(int partyID, Party[] parties) 
    {

        return false;
    }
    public static boolean checkIDValid(String ID)
    {

        return true;
    }

}
